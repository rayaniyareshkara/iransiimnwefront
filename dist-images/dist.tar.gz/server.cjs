var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express2 = __toESM(require("express"), 1);
var import_promises2 = __toESM(require("node:fs/promises"), 1);
var import_node_path3 = __toESM(require("node:path"), 1);

// server/config.ts
var import_config = require("dotenv/config");
var import_node_path = __toESM(require("node:path"), 1);
function optionalEnv(name, fallback) {
  return process.env[name]?.trim() || fallback;
}
var port = Number(optionalEnv("PORT", "3000"));
var isProduction = process.env.NODE_ENV === "production";
function resolvePublicBaseUrl() {
  const raw = optionalEnv("PUBLIC_BASE_URL", `http://localhost:${port}`).replace(/\/+$/, "");
  let parsed;
  try {
    parsed = new URL(raw);
  } catch {
    console.warn(`PUBLIC_BASE_URL \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A: ${raw}\u060C \u0627\u0632 \u067E\u06CC\u0634\u200C\u0641\u0631\u0636 \u0627\u0633\u062A\u0641\u0627\u062F\u0647 \u0645\u06CC\u200C\u0634\u0648\u062F.`);
    return `http://localhost:${port}`;
  }
  if (isProduction) {
    if (parsed.protocol !== "https:" || /^(localhost$|127\.|0\.0\.0\.0$|\[?::1)/.test(parsed.hostname)) {
      console.warn(
        `\u0647\u0634\u062F\u0627\u0631: PUBLIC_BASE_URL (${raw}) \u062F\u0631 \u062D\u0627\u0644\u062A production \u0631\u0648\u06CC HTTPS \u0648 \u062F\u0627\u0645\u0646\u0647 \u0639\u0645\u0648\u0645\u06CC \u062A\u0646\u0638\u06CC\u0645 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A.`
      );
    }
  }
  return parsed.origin;
}
var config = {
  port,
  /** مرچنت زیبال؛ در صورت عدم تنظیم از مرچنت تستی (zibal) استفاده می‌شود */
  zibalMerchant: optionalEnv("ZIBAL_MERCHANT", "zibal"),
  zibalBaseUrl: optionalEnv("ZIBAL_BASE_URL", "https://gateway.zibal.ir"),
  /**
   * آدرس عمومی اپلیکیشن. مبنای ساخت callbackUrl است، پس باید همان دامنه‌ای
   * باشد که کاربر با آن پرداخت را شروع می‌کند.
   */
  publicBaseUrl: resolvePublicBaseUrl(),
  isProduction,
  /**
   * منبع معتبر قیمت. همان سرویسی که صفحه‌ی جزئیات از آن قیمت می‌گیرد؛ مبلغ
   * پرداخت هرگز از فرانت پذیرفته نمی‌شود و همیشه از اینجا خوانده می‌شود.
   */
  numberSearchUrl: optionalEnv("NUMBER_SEARCH_URL", "https://iransiim.ir/api/search"),
  numberSearchOrigin: optionalEnv("NUMBER_SEARCH_ORIGIN", "https://iransiim.ir"),
  numberSearchHost: optionalEnv("NUMBER_SEARCH_HOST", "iransiim.ir"),
  productImageOrigin: optionalEnv("PRODUCT_IMAGE_ORIGIN", "https://shop.irancell.ir"),
  productImageHost: optionalEnv("PRODUCT_IMAGE_HOST", "shop.irancell.ir"),
  /** محل نگهداری فایل سبک تراکنش‌ها (جلوگیری از پردازش تکراری). */
  dataDir: optionalEnv("DATA_DIR", import_node_path.default.resolve(process.cwd(), "server-data")),
  /** مسیرهای SPA که کاربر بعد از بررسی پرداخت به آن‌ها هدایت می‌شود. */
  successPath: "/store/success",
  failurePath: "/store/payment-failed",
  /** سقف زمان انتظار برای سرویس‌های بیرونی. */
  upstreamTimeoutMs: Number(optionalEnv("UPSTREAM_TIMEOUT_MS", "15000"))
};
var API_PREFIX = "/fapi";
var CALLBACK_PATH = `${API_PREFIX}/payment/callback`;
function buildCallbackUrl() {
  return `${config.publicBaseUrl}${CALLBACK_PATH}`;
}

// server/routes.ts
var import_express = require("express");

// server/paymentService.ts
var import_uuid = require("uuid");

// server/http.ts
var UpstreamError = class extends Error {
  constructor(message, cause) {
    super(message);
    this.cause = cause;
    this.name = "UpstreamError";
  }
};
async function postJson(url, body) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), config.upstreamTimeoutMs);
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      signal: controller.signal
    });
    if (!response.ok) {
      throw new UpstreamError(`${url} \u067E\u0627\u0633\u062E ${response.status} \u0628\u0631\u06AF\u0631\u062F\u0627\u0646\u062F`);
    }
    return await response.json();
  } catch (err) {
    if (err instanceof UpstreamError) throw err;
    throw new UpstreamError(`\u0627\u0631\u062A\u0628\u0627\u0637 \u0628\u0627 ${url} \u0628\u0631\u0642\u0631\u0627\u0631 \u0646\u0634\u062F`, err);
  } finally {
    clearTimeout(timer);
  }
}

// server/pricing.ts
var RIAL_PER_TOMAN = 10;
async function withRetry(operation, attempts = 2) {
  let lastError;
  for (let attempt = 1; attempt <= attempts; attempt++) {
    try {
      return await operation();
    } catch (err) {
      lastError = err;
      if (attempt < attempts) {
        console.warn(`Price lookup attempt ${attempt} failed, retrying:`, err);
        await new Promise((resolve) => setTimeout(resolve, 500));
      }
    }
  }
  throw lastError;
}
var NumberUnavailableError = class extends Error {
  constructor(phoneNumber) {
    super("\u0627\u06CC\u0646 \u0634\u0645\u0627\u0631\u0647 \u062F\u06CC\u06AF\u0631 \u0628\u0631\u0627\u06CC \u062E\u0631\u06CC\u062F \u0645\u0648\u062C\u0648\u062F \u0646\u06CC\u0633\u062A.");
    this.phoneNumber = phoneNumber;
    this.name = "NumberUnavailableError";
  }
};
async function getPriceQuote(phoneNumber) {
  const msisdn = phoneNumber.replace(/\D/g, "").replace(/^(?:0098|98|0)/, "");
  if (msisdn.length !== 10) {
    throw new NumberUnavailableError(phoneNumber);
  }
  const raw = await withRetry(
    () => postJson(config.numberSearchUrl, { pattern: msisdn })
  );
  if (raw.result_code !== 0) {
    throw new Error(raw.info?.fa?.message || "\u062E\u0637\u0627 \u062F\u0631 \u062F\u0631\u06CC\u0627\u0641\u062A \u0642\u06CC\u0645\u062A \u0634\u0645\u0627\u0631\u0647");
  }
  const numbers = raw.result?.numbers ?? [];
  const products = raw.result?.products ?? {};
  const match = numbers.find((n) => n.msisdn.replace(/\D/g, "") === msisdn);
  if (!match) {
    throw new NumberUnavailableError(phoneNumber);
  }
  const product = products[match.pool];
  const amountToman = (match.price ?? 0) + (product?.finalPrice ?? 0);
  if (!Number.isFinite(amountToman) || amountToman <= 0) {
    throw new Error("\u0642\u06CC\u0645\u062A \u0627\u06CC\u0646 \u0634\u0645\u0627\u0631\u0647 \u062F\u0631 \u062F\u0633\u062A\u0631\u0633 \u0646\u06CC\u0633\u062A.");
  }
  return {
    phoneNumber: `0${msisdn}`,
    amountToman,
    amountRial: Math.round(amountToman * RIAL_PER_TOMAN),
    title: product?.info?.fa?.title ?? product?.info?.fa?.name ?? "\u0633\u06CC\u0645\u200C\u06A9\u0627\u0631\u062A \u0627\u06CC\u0631\u0627\u0646\u0633\u0644",
    pool: match.pool,
    productId: product?.id ?? 0
  };
}

// server/transactionStore.ts
var import_promises = __toESM(require("node:fs/promises"), 1);
var import_node_path2 = __toESM(require("node:path"), 1);
var FILE_NAME = "transactions.json";
var cache = null;
var writeChain = Promise.resolve();
function filePath() {
  return import_node_path2.default.join(config.dataDir, FILE_NAME);
}
async function load() {
  if (cache) return cache;
  try {
    const content = await import_promises.default.readFile(filePath(), "utf8");
    const records = JSON.parse(content);
    cache = new Map(records.map((r) => [r.trackId, r]));
  } catch {
    cache = /* @__PURE__ */ new Map();
  }
  return cache;
}
async function persist() {
  const records = [...cache?.values() ?? []];
  const target = filePath();
  const temp = `${target}.${process.pid}.tmp`;
  await import_promises.default.mkdir(config.dataDir, { recursive: true });
  await import_promises.default.writeFile(temp, JSON.stringify(records, null, 2), "utf8");
  await import_promises.default.rename(temp, target);
}
function enqueueWrite() {
  writeChain = writeChain.then(persist, persist);
  return writeChain;
}
var transactionStore = {
  async get(trackId) {
    return (await load()).get(trackId);
  },
  /** ثبت تراکنش تازه‌ساخته‌شده، پیش از هدایت کاربر به درگاه. */
  async create(record) {
    const store = await load();
    const full = {
      ...record,
      status: "pending",
      delivered: false,
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    store.set(full.trackId, full);
    await enqueueWrite();
    return full;
  },
  async update(trackId, patch) {
    const store = await load();
    const existing = store.get(trackId);
    if (!existing) return void 0;
    const updated = { ...existing, ...patch };
    store.set(trackId, updated);
    await enqueueWrite();
    return updated;
  }
};

// server/zibalClient.ts
var RESULT_MESSAGES = {
  100: "\u0645\u0648\u0641\u0642",
  102: "\u0645\u0631\u0686\u0646\u062A \u06CC\u0627\u0641\u062A \u0646\u0634\u062F.",
  103: "\u0645\u0631\u0686\u0646\u062A \u063A\u06CC\u0631\u0641\u0639\u0627\u0644 \u0627\u0633\u062A.",
  104: "\u0645\u0631\u0686\u0646\u062A \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A.",
  105: "\u0645\u0628\u0644\u063A \u062A\u0631\u0627\u06A9\u0646\u0634 \u0628\u0627\u06CC\u062F \u0628\u06CC\u0634\u062A\u0631 \u0627\u0632 \u06F1\u066C\u06F0\u06F0\u06F0 \u0631\u06CC\u0627\u0644 \u0628\u0627\u0634\u062F.",
  106: "\u0622\u062F\u0631\u0633 \u0628\u0627\u0632\u06AF\u0634\u062A (callbackUrl) \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A.",
  113: "\u0645\u0628\u0644\u063A \u062A\u0631\u0627\u06A9\u0646\u0634 \u0627\u0632 \u0633\u0642\u0641 \u0645\u062C\u0627\u0632 \u0628\u06CC\u0634\u062A\u0631 \u0627\u0633\u062A.",
  201: "\u0627\u06CC\u0646 \u062A\u0631\u0627\u06A9\u0646\u0634 \u0642\u0628\u0644\u0627\u064B \u062A\u0623\u06CC\u06CC\u062F \u0634\u062F\u0647 \u0627\u0633\u062A.",
  202: "\u062A\u0631\u0627\u06A9\u0646\u0634 \u067E\u0631\u062F\u0627\u062E\u062A \u0646\u0634\u062F\u0647 \u06CC\u0627 \u0646\u0627\u0645\u0648\u0641\u0642 \u0628\u0648\u062F\u0647 \u0627\u0633\u062A.",
  203: "\u0634\u0646\u0627\u0633\u0647 \u062A\u0631\u0627\u06A9\u0646\u0634 (trackId) \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A."
};
function describeResult(result, fallback) {
  return RESULT_MESSAGES[result] ?? fallback ?? `\u062E\u0637\u0627\u06CC \u062F\u0631\u06AF\u0627\u0647 \u067E\u0631\u062F\u0627\u062E\u062A (\u06A9\u062F ${result})`;
}
var RESULT_SUCCESS = 100;
var RESULT_ALREADY_VERIFIED = 201;
function requestPayment(input) {
  return postJson(`${config.zibalBaseUrl}/v1/request`, {
    merchant: config.zibalMerchant,
    amount: input.amountRial,
    callbackUrl: input.callbackUrl,
    description: input.description,
    orderId: input.orderId,
    mobile: input.mobile
  });
}
function verifyPayment(trackId) {
  return postJson(`${config.zibalBaseUrl}/v1/verify`, {
    merchant: config.zibalMerchant,
    trackId
  });
}
function buildStartUrl(trackId) {
  return `${config.zibalBaseUrl}/start/${trackId}`;
}

// server/validation.ts
var MAX_LENGTHS = {
  fullName: 80,
  mobile: 11,
  fatherName: 50,
  nationalCode: 10,
  secondaryRequestNumber: 11,
  address: 180,
  plaque: 10,
  purchasedNumber: 11
};
var MOBILE_PATTERN = /^09\d{9}$/;
var NATIONAL_CODE_PATTERN = /^\d{10}$/;
var SECONDARY_NUMBER_PATTERN = /^\d{8,11}$/;
var CONTROL_CHARS = /[\u0000-\u001F\u007F]+/g;
function toLatinDigits(value) {
  return value.replace(/[۰-۹]/g, (d) => String("\u06F0\u06F1\u06F2\u06F3\u06F4\u06F5\u06F6\u06F7\u06F8\u06F9".indexOf(d))).replace(/[٠-٩]/g, (d) => String("\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669".indexOf(d)));
}
function sanitizeText(value, maxLength) {
  if (typeof value !== "string") return "";
  return value.replace(CONTROL_CHARS, " ").replace(/\s+/g, " ").trim().slice(0, maxLength);
}
function sanitizeDigits(value, maxLength) {
  if (typeof value !== "string" && typeof value !== "number") return "";
  return toLatinDigits(String(value)).replace(/\D/g, "").slice(0, maxLength);
}
function validateBuyer(body) {
  const value = {
    fullName: sanitizeText(body.fullName, MAX_LENGTHS.fullName),
    mobile: sanitizeDigits(body.mobile, MAX_LENGTHS.mobile),
    fatherName: sanitizeText(body.fatherName, MAX_LENGTHS.fatherName),
    nationalCode: sanitizeDigits(body.nationalCode, MAX_LENGTHS.nationalCode),
    secondaryRequestNumber: sanitizeDigits(
      body.secondaryRequestNumber,
      MAX_LENGTHS.secondaryRequestNumber
    ),
    address: sanitizeText(body.address, MAX_LENGTHS.address),
    plaque: sanitizeText(body.plaque, MAX_LENGTHS.plaque),
    purchasedNumber: sanitizeDigits(body.purchasedNumber, MAX_LENGTHS.purchasedNumber)
  };
  const errors = {};
  if (value.fullName.length < 3) {
    errors.fullName = "\u0646\u0627\u0645 \u0648 \u0646\u0627\u0645 \u062E\u0627\u0646\u0648\u0627\u062F\u06AF\u06CC \u0628\u0627\u06CC\u062F \u062D\u062F\u0627\u0642\u0644 \u06F3 \u062D\u0631\u0641 \u0628\u0627\u0634\u062F.";
  }
  if (!MOBILE_PATTERN.test(value.mobile)) {
    errors.mobile = "\u0634\u0645\u0627\u0631\u0647 \u0645\u0648\u0628\u0627\u06CC\u0644 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A (\u0645\u062B\u0627\u0644: 09123456789).";
  }
  if (value.fatherName.length < 2) {
    errors.fatherName = "\u0648\u0627\u0631\u062F \u06A9\u0631\u062F\u0646 \u0646\u0627\u0645 \u067E\u062F\u0631 \u0627\u0644\u0632\u0627\u0645\u06CC \u0627\u0633\u062A.";
  }
  if (!NATIONAL_CODE_PATTERN.test(value.nationalCode)) {
    errors.nationalCode = "\u06A9\u062F \u0645\u0644\u06CC \u0628\u0627\u06CC\u062F \u06F1\u06F0 \u0631\u0642\u0645 \u0628\u0627\u0634\u062F.";
  }
  if (value.secondaryRequestNumber && !SECONDARY_NUMBER_PATTERN.test(value.secondaryRequestNumber)) {
    errors.secondaryRequestNumber = "\u0634\u0645\u0627\u0631\u0647 \u062F\u0631\u062E\u0648\u0627\u0633\u062A \u062F\u0648\u0645 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A.";
  }
  if (value.address.length < 8) {
    errors.address = "\u0622\u062F\u0631\u0633 \u06A9\u0627\u0645\u0644 \u0631\u0627 \u0648\u0627\u0631\u062F \u06A9\u0646\u06CC\u062F.";
  }
  if (value.plaque.length < 1) {
    errors.plaque = "\u0648\u0627\u0631\u062F \u06A9\u0631\u062F\u0646 \u067E\u0644\u0627\u06A9 \u0627\u0644\u0632\u0627\u0645\u06CC \u0627\u0633\u062A.";
  }
  if (!MOBILE_PATTERN.test(value.purchasedNumber)) {
    errors.purchasedNumber = "\u0634\u0645\u0627\u0631\u0647\u200C\u06CC \u062E\u0631\u06CC\u062F\u0627\u0631\u06CC\u200C\u0634\u062F\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A.";
  }
  return { ok: Object.keys(errors).length === 0, errors, value };
}
function buildDescription(buyer) {
  return JSON.stringify(buyer);
}
function parseDescription(description) {
  if (typeof description !== "string" || !description.trim()) return null;
  try {
    const parsed = JSON.parse(description);
    if (!parsed || typeof parsed !== "object") return null;
    return {
      fullName: String(parsed.fullName ?? ""),
      mobile: String(parsed.mobile ?? ""),
      fatherName: String(parsed.fatherName ?? ""),
      nationalCode: String(parsed.nationalCode ?? ""),
      secondaryRequestNumber: String(parsed.secondaryRequestNumber ?? ""),
      address: String(parsed.address ?? ""),
      plaque: String(parsed.plaque ?? ""),
      purchasedNumber: String(parsed.purchasedNumber ?? "")
    };
  } catch {
    return null;
  }
}

// server/paymentService.ts
var RESULT_TTL_MS = 15 * 60 * 1e3;
var verifiedResults = /* @__PURE__ */ new Map();
function rememberResult(trackId, payload) {
  const now = Date.now();
  for (const [key, item] of verifiedResults) {
    if (item.expiresAt <= now) verifiedResults.delete(key);
  }
  verifiedResults.set(trackId, { ...payload, expiresAt: now + RESULT_TTL_MS });
}
function readResult(trackId) {
  const payload = verifiedResults.get(trackId);
  if (!payload) return null;
  if (payload.expiresAt <= Date.now()) {
    verifiedResults.delete(trackId);
    return null;
  }
  return payload;
}
async function startPayment(body) {
  const validation = validateBuyer(body);
  if (!validation.ok) {
    return { kind: "invalid", errors: validation.errors };
  }
  const buyer = validation.value;
  let quote;
  try {
    quote = await getPriceQuote(buyer.purchasedNumber);
  } catch (err) {
    if (err instanceof NumberUnavailableError) {
      return { kind: "unavailable", message: err.message };
    }
    console.error("Price lookup failed:", err);
    return { kind: "gateway-error", message: "\u062F\u0631\u06CC\u0627\u0641\u062A \u0642\u06CC\u0645\u062A \u0634\u0645\u0627\u0631\u0647 \u0645\u0645\u06A9\u0646 \u0646\u0634\u062F. \u062F\u0648\u0628\u0627\u0631\u0647 \u062A\u0644\u0627\u0634 \u06A9\u0646\u06CC\u062F." };
  }
  const clientAmount = Number(body.amount);
  if (Number.isFinite(clientAmount) && clientAmount > 0 && clientAmount !== quote.amountToman) {
    return {
      kind: "price-changed",
      amountToman: quote.amountToman,
      message: "\u0642\u06CC\u0645\u062A \u0627\u06CC\u0646 \u0634\u0645\u0627\u0631\u0647 \u0628\u0647\u200C\u0631\u0648\u0632\u0631\u0633\u0627\u0646\u06CC \u0634\u062F\u0647 \u0627\u0633\u062A. \u0644\u0637\u0641\u0627\u064B \u0645\u0628\u0644\u063A \u062C\u062F\u06CC\u062F \u0631\u0627 \u062A\u0623\u06CC\u06CC\u062F \u06A9\u0646\u06CC\u062F."
    };
  }
  const orderId = (0, import_uuid.v4)();
  const description = buildDescription(buyer);
  let response;
  try {
    response = await requestPayment({
      amountRial: quote.amountRial,
      callbackUrl: buildCallbackUrl(),
      description,
      orderId,
      mobile: buyer.mobile
    });
  } catch (err) {
    console.error("Zibal request failed:", err);
    return { kind: "gateway-error", message: "\u0627\u0631\u062A\u0628\u0627\u0637 \u0628\u0627 \u062F\u0631\u06AF\u0627\u0647 \u067E\u0631\u062F\u0627\u062E\u062A \u0628\u0631\u0642\u0631\u0627\u0631 \u0646\u0634\u062F." };
  }
  if (response.result !== RESULT_SUCCESS || !response.trackId) {
    return {
      kind: "gateway-error",
      message: describeResult(response.result, response.message)
    };
  }
  const trackId = String(response.trackId);
  await transactionStore.create({
    trackId,
    orderId,
    amountRial: quote.amountRial,
    purchasedNumber: buyer.purchasedNumber
  });
  return {
    kind: "ok",
    trackId,
    orderId,
    paymentUrl: buildStartUrl(trackId),
    amountToman: quote.amountToman
  };
}
async function verifyTransaction(trackId) {
  const clean = String(trackId ?? "").replace(/\D/g, "");
  if (!clean) {
    return { success: false, firstTime: false, trackId: "", message: "\u0634\u0646\u0627\u0633\u0647 \u062A\u0631\u0627\u06A9\u0646\u0634 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A." };
  }
  const record = await transactionStore.get(clean);
  if (!record) {
    return {
      success: false,
      firstTime: false,
      trackId: clean,
      message: "\u0627\u06CC\u0646 \u062A\u0631\u0627\u06A9\u0646\u0634 \u062F\u0631 \u0633\u0627\u0645\u0627\u0646\u0647 \u062B\u0628\u062A \u0646\u0634\u062F\u0647 \u0627\u0633\u062A."
    };
  }
  if (record.status === "verified") {
    return {
      success: true,
      firstTime: false,
      trackId: clean,
      orderId: record.orderId,
      amountToman: record.amountRial / 10,
      purchasedNumber: record.purchasedNumber,
      refNumber: record.refNumber,
      message: "\u0627\u06CC\u0646 \u067E\u0631\u062F\u0627\u062E\u062A \u067E\u06CC\u0634\u200C\u062A\u0631 \u062A\u0623\u06CC\u06CC\u062F \u0634\u062F\u0647 \u0627\u0633\u062A."
    };
  }
  let response;
  try {
    response = await verifyPayment(clean);
  } catch (err) {
    console.error("Zibal verify failed:", err);
    return {
      success: false,
      firstTime: false,
      trackId: clean,
      message: "\u0627\u0631\u062A\u0628\u0627\u0637 \u0628\u0627 \u062F\u0631\u06AF\u0627\u0647 \u0628\u0631\u0627\u06CC \u062A\u0623\u06CC\u06CC\u062F \u067E\u0631\u062F\u0627\u062E\u062A \u0628\u0631\u0642\u0631\u0627\u0631 \u0646\u0634\u062F. \u0644\u062D\u0638\u0627\u062A\u06CC \u0628\u0639\u062F \u062F\u0648\u0628\u0627\u0631\u0647 \u062A\u0644\u0627\u0634 \u06A9\u0646\u06CC\u062F."
    };
  }
  const isSuccess = response.result === RESULT_SUCCESS || response.result === RESULT_ALREADY_VERIFIED;
  if (!isSuccess) {
    await transactionStore.update(clean, {
      status: "failed",
      failureReason: describeResult(response.result, response.message)
    });
    return {
      success: false,
      firstTime: false,
      trackId: clean,
      orderId: record.orderId,
      message: describeResult(response.result, response.message)
    };
  }
  if (typeof response.amount === "number" && response.amount !== record.amountRial) {
    console.error(
      `Amount mismatch for trackId ${clean}: expected ${record.amountRial}, got ${response.amount}`
    );
    await transactionStore.update(clean, {
      status: "failed",
      failureReason: "amount-mismatch"
    });
    return {
      success: false,
      firstTime: false,
      trackId: clean,
      orderId: record.orderId,
      message: "\u0645\u0628\u0644\u063A \u062A\u0631\u0627\u06A9\u0646\u0634 \u0628\u0627 \u0645\u0628\u0644\u063A \u0633\u0641\u0627\u0631\u0634 \u0647\u0645\u200C\u062E\u0648\u0627\u0646\u06CC \u0646\u062F\u0627\u0631\u062F. \u0628\u0627 \u067E\u0634\u062A\u06CC\u0628\u0627\u0646\u06CC \u062A\u0645\u0627\u0633 \u0628\u06AF\u06CC\u0631\u06CC\u062F."
    };
  }
  const buyer = parseDescription(response.description);
  const refNumber = response.refNumber !== void 0 ? String(response.refNumber) : void 0;
  const firstTime = !record.delivered;
  await transactionStore.update(clean, {
    status: "verified",
    delivered: true,
    verifiedAt: (/* @__PURE__ */ new Date()).toISOString(),
    refNumber
  });
  if (buyer) {
    rememberResult(clean, {
      buyer,
      amountRial: record.amountRial,
      refNumber,
      paidAt: response.paidAt
    });
  }
  return {
    success: true,
    firstTime,
    trackId: clean,
    orderId: record.orderId,
    amountToman: record.amountRial / 10,
    purchasedNumber: buyer?.purchasedNumber || record.purchasedNumber,
    refNumber,
    message: firstTime ? "\u067E\u0631\u062F\u0627\u062E\u062A \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062A\u0623\u06CC\u06CC\u062F \u0634\u062F." : "\u0627\u06CC\u0646 \u067E\u0631\u062F\u0627\u062E\u062A \u067E\u06CC\u0634\u200C\u062A\u0631 \u062A\u0623\u06CC\u06CC\u062F \u0634\u062F\u0647 \u0627\u0633\u062A."
  };
}

// server/routes.ts
var router = (0, import_express.Router)();
function escapeHtml(value) {
  return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}
function successUrl(outcome) {
  const params = new URLSearchParams({ trackId: outcome.trackId });
  if (outcome.orderId) params.set("orderId", outcome.orderId);
  if (outcome.purchasedNumber) params.set("number", outcome.purchasedNumber);
  return `${config.successPath}?${params.toString()}`;
}
function failureUrl(message, trackId, number) {
  const params = new URLSearchParams({ reason: message });
  if (trackId) params.set("trackId", trackId);
  if (number) params.set("number", number);
  return `${config.failurePath}?${params.toString()}`;
}
router.post(`${API_PREFIX}/payment/request`, async (req, res) => {
  const outcome = await startPayment(req.body ?? {});
  switch (outcome.kind) {
    case "invalid":
      return res.status(422).json({ ok: false, errors: outcome.errors });
    case "unavailable":
      return res.status(409).json({ ok: false, code: "number-unavailable", message: outcome.message });
    case "price-changed":
      return res.status(409).json({
        ok: false,
        code: "price-changed",
        message: outcome.message,
        amountToman: outcome.amountToman
      });
    case "gateway-error":
      return res.status(502).json({ ok: false, code: "gateway-error", message: outcome.message });
    case "ok":
      return res.json({
        ok: true,
        trackId: outcome.trackId,
        orderId: outcome.orderId,
        paymentUrl: outcome.paymentUrl,
        amountToman: outcome.amountToman
      });
  }
});
router.post(`${API_PREFIX}/payment/verify`, async (req, res) => {
  const trackId = String(req.body?.trackId ?? "");
  const outcome = await verifyTransaction(trackId);
  res.json({
    ...outcome,
    redirectTo: outcome.success ? successUrl(outcome) : failureUrl(outcome.message, outcome.trackId, outcome.purchasedNumber)
  });
});
router.get(`${API_PREFIX}/payment/result/:trackId`, (req, res) => {
  const payload = readResult(req.params.trackId);
  if (!payload) {
    return res.status(404).json({ ok: false, message: "\u0646\u062A\u06CC\u062C\u0647\u200C\u06CC \u0627\u06CC\u0646 \u062A\u0631\u0627\u06A9\u0646\u0634 \u062F\u0631 \u062F\u0633\u062A\u0631\u0633 \u0646\u06CC\u0633\u062A." });
  }
  res.json({
    ok: true,
    buyer: payload.buyer,
    amountToman: payload.amountRial / 10,
    refNumber: payload.refNumber,
    paidAt: payload.paidAt
  });
});
router.get(CALLBACK_PATH, (req, res) => {
  const trackId = String(req.query.trackId ?? "").replace(/\D/g, "");
  const success = String(req.query.success ?? "");
  const status = String(req.query.status ?? "");
  const initialMessage = success === "1" ? "\u067E\u0631\u062F\u0627\u062E\u062A \u0627\u0646\u062C\u0627\u0645 \u0634\u062F. \u062F\u0631 \u062D\u0627\u0644 \u0628\u0631\u0631\u0633\u06CC \u0648 \u062A\u0623\u06CC\u06CC\u062F \u0646\u0647\u0627\u06CC\u06CC\u2026" : "\u062F\u0631 \u062D\u0627\u0644 \u0628\u0631\u0631\u0633\u06CC \u0648\u0636\u0639\u06CC\u062A \u067E\u0631\u062F\u0627\u062E\u062A\u2026";
  if (!trackId) {
    return res.redirect(failureUrl("\u0628\u0627\u0632\u06AF\u0634\u062A \u0627\u0632 \u062F\u0631\u06AF\u0627\u0647 \u0628\u062F\u0648\u0646 \u0634\u0646\u0627\u0633\u0647 \u062A\u0631\u0627\u06A9\u0646\u0634 \u0627\u0646\u062C\u0627\u0645 \u0634\u062F."));
  }
  res.set("Cache-Control", "no-store");
  res.type("html").send(`<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>\u062F\u0631 \u062D\u0627\u0644 \u0628\u0631\u0631\u0633\u06CC \u067E\u0631\u062F\u0627\u062E\u062A</title>
<noscript><meta http-equiv="refresh" content="0;url=${escapeHtml(
    `${CALLBACK_PATH}/resolve?trackId=${trackId}`
  )}"></noscript>
<style>
  body{margin:0;min-height:100vh;display:flex;flex-direction:column;align-items:center;
       justify-content:center;gap:16px;background:#121214;color:#fff;
       font-family:Vazirmatn,system-ui,sans-serif}
  .spinner{width:40px;height:40px;border:3px solid #FFBE00;border-top-color:transparent;
           border-radius:50%;animation:spin 1s linear infinite}
  @keyframes spin{to{transform:rotate(360deg)}}
  p{font-size:14px;color:#d1d5db;margin:0}
  small{color:#6b7280;font-family:monospace}
</style>
</head>
<body>
  <div class="spinner"></div>
  <p>${escapeHtml(initialMessage)}</p>
  <small>trackId: ${escapeHtml(trackId)}${status ? ` \xB7 status: ${escapeHtml(status)}` : ""}</small>
<script>
  fetch('${API_PREFIX}/payment/verify', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ trackId: ${JSON.stringify(trackId)} })
  })
    .then(function (r) { return r.json(); })
    .then(function (d) { window.location.replace(d.redirectTo); })
    .catch(function () {
      window.location.replace(${JSON.stringify(
    `${CALLBACK_PATH}/resolve?trackId=`
  )} + ${JSON.stringify(trackId)});
    });
</script>
</body>
</html>`);
});
router.get(`${CALLBACK_PATH}/resolve`, async (req, res) => {
  const trackId = String(req.query.trackId ?? "");
  const outcome = await verifyTransaction(trackId);
  res.redirect(
    outcome.success ? successUrl(outcome) : failureUrl(outcome.message, outcome.trackId, outcome.purchasedNumber)
  );
});

// server.ts
async function startServer() {
  const app = (0, import_express2.default)();
  const PORT = Number(process.env.PORT) || 3e3;
  app.set("trust proxy", true);
  app.disable("x-powered-by");
  app.get("/healthz", (_req, res) => {
    res.type("text/plain").send("ok\n");
  });
  app.get(`${API_PREFIX}/payment/healthz`, (_req, res) => {
    res.json({ ok: true, merchantConfigured: Boolean(config.zibalMerchant) });
  });
  app.use(import_express2.default.json({ limit: "32kb" }));
  app.use(router);
  app.all("/api/*", async (req, res) => {
    try {
      const upstreamUrl = `${config.numberSearchOrigin}${req.originalUrl}`;
      const headers = {
        host: config.numberSearchHost,
        "content-type": req.get("content-type") || "application/json",
        "user-agent": req.get("user-agent") || "iransiim-client",
        accept: req.get("accept") || "application/json"
      };
      const hasBody = ["POST", "PUT", "PATCH"].includes(req.method);
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), config.upstreamTimeoutMs);
      const upstreamResponse = await fetch(upstreamUrl, {
        method: req.method,
        headers,
        body: hasBody ? JSON.stringify(req.body) : void 0,
        signal: controller.signal
      });
      clearTimeout(timer);
      res.status(upstreamResponse.status);
      upstreamResponse.headers.forEach((val, key) => {
        const lower = key.toLowerCase();
        if (!["transfer-encoding", "content-encoding", "content-length", "connection"].includes(lower)) {
          res.setHeader(key, val);
        }
      });
      const buffer = await upstreamResponse.arrayBuffer();
      res.send(Buffer.from(buffer));
    } catch (err) {
      console.error("API proxy error:", err);
      res.status(502).json({ ok: false, message: "\u062E\u0637\u0627 \u062F\u0631 \u0627\u0631\u062A\u0628\u0627\u0637 \u0628\u0627 \u0633\u0631\u0648\u06CC\u0633 \u062C\u0633\u062A\u062C\u0648\u06CC \u0634\u0645\u0627\u0631\u0647." });
    }
  });
  app.all("/product-image/*", async (req, res) => {
    try {
      const subPath = req.params[0] || req.originalUrl.replace(/^\/product-image\/?/, "");
      const upstreamUrl = `${config.productImageOrigin}/${subPath}`;
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 1e4);
      const upstreamResponse = await fetch(upstreamUrl, {
        headers: {
          host: config.productImageHost,
          "user-agent": "Mozilla/5.0 (compatible; IransiimProxy/1.0)"
        },
        signal: controller.signal
      });
      clearTimeout(timer);
      res.status(upstreamResponse.status);
      upstreamResponse.headers.forEach((val, key) => {
        const lower = key.toLowerCase();
        if (!["transfer-encoding", "content-encoding", "content-length", "connection"].includes(lower)) {
          res.setHeader(key, val);
        }
      });
      const buffer = await upstreamResponse.arrayBuffer();
      res.send(Buffer.from(buffer));
    } catch {
      res.status(504).end();
    }
  });
  if (process.env.NODE_ENV !== "production") {
    const { createServer } = await import("vite");
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
    app.use("*", async (req, res, next) => {
      try {
        const url = req.originalUrl;
        const indexPath = import_node_path3.default.resolve(process.cwd(), "index.html");
        let template = await import_promises2.default.readFile(indexPath, "utf-8");
        template = await vite.transformIndexHtml(url, template);
        res.status(200).set({ "Content-Type": "text/html" }).end(template);
      } catch (e) {
        vite.ssrFixStacktrace(e);
        next(e);
      }
    });
  } else {
    const distPath = import_node_path3.default.join(process.cwd(), "dist");
    app.use(import_express2.default.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(import_node_path3.default.join(distPath, "index.html"));
    });
  }
  app.use((err, _req, res, _next) => {
    console.error("Unhandled server error:", err);
    res.status(500).json({ ok: false, message: "\u062E\u0637\u0627\u06CC \u063A\u06CC\u0631\u0645\u0646\u062A\u0638\u0631\u0647 \u062F\u0631 \u0633\u0631\u0648\u0631." });
  });
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
    console.log(`Mode: ${process.env.NODE_ENV || "development"}`);
  });
}
startServer().catch((err) => {
  console.error("Failed to start server:", err);
  process.exit(1);
});
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
//# sourceMappingURL=server.cjs.map
